<div class="nav-header">
            <div class="brand-logo">
                <a href="javascript:void(0)" class="logo">
                    <b class="logo-abbr"><img src="<?= base_url()?>assets/images/logo.png" alt=""> </b>
                    <span class="logo-compact"><img src="<?= base_url()?>assets/images/logo-compact.png" alt=""></span>
                    <span class="brand-title">
                        <img src="<?= base_url()?>assets/images/Nia-logo-Approved-TM-2.png" alt="" style="width: 75px;
    margin-top: -13%;
    margin-left: 18%;">
                    </span>
                </a>
            </div>
        </div>