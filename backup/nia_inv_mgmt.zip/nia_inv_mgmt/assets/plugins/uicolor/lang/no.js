/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","no",{title:"Fargevelger for brukergrensesnitt",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Forhåndsdefinerte fargesett",config:"Lim inn følgende tekst i din config.js-fil"});