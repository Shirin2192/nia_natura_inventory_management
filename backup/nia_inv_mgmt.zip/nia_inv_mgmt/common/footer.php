<div class="footer">
         <div class="copyright">
            <p>Copyright &copy; SDA <a href="javascript:void(0);">Nia Natura Inventory Management</a> <?= date("Y"); ?></p>
         </div>
      </div>